# LD1115H And LD1125H For ESPHome

LD1115H Code in LD1115H Folder

LD1125H Code in LD1125H Folder

Put LD11X5.h at /ESPHome/

**Note that in Example use ESP32-S2 Broad**
